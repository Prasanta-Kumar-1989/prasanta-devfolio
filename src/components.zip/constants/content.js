export const HERO = {
  title: "Senior Front-End Developer",
  subtitle:
    "Building scalable, enterprise-grade web applications for global products",
  experience: "8+ Years Experience",
  location: "Bangalore, India",
};
