export const ENTERPRISE_PROJECTS = [
  {
    title: "ADCP (Application Data Control Panel)",
    description:
      "Enterprise dashboard for managing application-level data and permissions.",
    tech: ["React", "Redux", "TypeScript", "GraphQL"],
    nda: true,
  },
  {
    title: "Supply Chain Analytics Platform",
    description:
      "Internal analytics platform for real-time supply chain visibility.",
    tech: ["React", "AG Grid", "Node.js"],
    nda: true,
  },
];

export const PERSONAL_PROJECTS = [
  {
    title: "Developer Portfolio",
    description: "Personal portfolio built using React and modern CSS.",
    tech: ["React", "CSS", "Responsive Design"],
    github: "https://github.com/your-username/portfolio",
  },
];
