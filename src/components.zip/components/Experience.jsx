export default function Experience() {
  return (
    <section id="experience" className="py-10">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-6">Experience</h2>
        <div className="p-6 bg-gray-50 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl">
          <h3 className="font-semibold">Senior Software Engineer – Walmart</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
            Building enterprise-scale React applications used globally.
          </p>
        </div>
      </div>
    </section>
  );
}
