import ProjectCard from "./ProjectCard";
import { ENTERPRISE_PROJECTS } from "../constants/projects";

export default function Projects() {
  return (
    <section id="projects" className="section projects">
      <div className="max-w-5xl mx-auto px-4 grid gap-10">
        <div className="projects-section">
          <h3 className="section-subtitle">Enterprise Projects</h3>

          <div className="projects-list">
            {ENTERPRISE_PROJECTS.map((project) => (
              <ProjectCard key={project.title} project={project} />
            ))}
          </div>
        </div>
        {/* <div className="projects-section">
          <h3 className="section-subtitle">Personal Projects</h3>

          <div className="projects-list">
            {PERSONAL_PROJECTS.map((project) => (
              <ProjectCard key={project.title} project={project} personal />
            ))}
          </div>
        </div> */}
      </div>
    </section>
  );
}
