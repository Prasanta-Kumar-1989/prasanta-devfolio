export default function About() {
  return (
    <section id="about" className="py-10">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-4">About Me</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Senior Front-End Developer with 8+ years of experience working on
          enterprise-grade React applications.
        </p>
      </div>
    </section>
  );
}
