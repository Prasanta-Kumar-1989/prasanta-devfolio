export const CONTACT_DETAILS = [
  {
    icon: "📧",
    label: "Email",
    value: "prasanta.sitha@gmail.com",
    link: "mailto:prasanta.sitha@gmail.com",
  },
  {
    icon: "🔗",
    label: "LinkedIn",
    value: "linkedin.com/in/prasanta-sitha",
    link: "https://linkedin.com/in/prasanta-sitha",
  },
  {
    icon: "📍",
    label: "Location",
    value: "Bangalore, India",
  },
];
