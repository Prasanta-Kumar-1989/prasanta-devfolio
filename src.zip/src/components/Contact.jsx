export default function Contact() {
  return (
    <section id="contact" className="py-10">
      <div className="max-w-5xl mx-auto px-4 grid md:grid-cols-2 gap-10">
        <div>
          <h2 className="text-2xl font-semibold">Contact Me</h2>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            I’m open to new opportunities and collaborations.
          </p>
          <p className="mt-4">📧 pksitha1989@gmail.com</p>
          <p>📍 Bangalore, India</p>
        </div>

        <form className="space-y-4">
          <input
            className="w-full px-4 py-3 rounded-lg border"
            placeholder="Your Name"
          />
          <input
            className="w-full px-4 py-3 rounded-lg border"
            placeholder="Your Email"
          />
          <textarea
            className="w-full px-4 py-3 rounded-lg border"
            rows="4"
            placeholder="Your Message"
          />
          <button className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold">
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
}
